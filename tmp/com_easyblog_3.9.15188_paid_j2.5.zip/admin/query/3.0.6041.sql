ALTER TABLE `#__easyblog_post` ADD `robots` TEXT NULL;
ALTER TABLE `#__easyblog_drafts` ADD `robots` TEXT NULL;